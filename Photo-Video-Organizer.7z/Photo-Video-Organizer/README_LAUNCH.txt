=== HOW TO LAUNCH ===

1. EASY (Recommended):
   - Double-click "PhotoOrganizer.bat"

2. ALTERNATIVE:
   - Right-click on "Сортировка_фото_GUI.ps1"
   - Select "Run with PowerShell"

3. IF YOU HAVE ERRORS:
   - Run "Install.bat" once to configure permissions
   - Then use method 1 or 2

=== FILES ===
- Сортировка_фото_GUI.ps1 - Main script
- PhotoOrganizer.bat - Launcher (double-click this!)
- Install.bat - Permission setup (run once if needed)